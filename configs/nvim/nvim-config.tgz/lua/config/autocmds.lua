-- Autocmds are automatically loaded on the VeryLazy event
-- Default autocmds that are always set: https://github.com/LazyVim/LazyVim/blob/main/lua/lazyvim/config/autocmds.lua
--
-- Add any additional autocmds here
-- with `vim.api.nvim_create_autocmd`
--
-- Or remove existing autocmds by their group name (which is prefixed with `lazyvim_` for the defaults)
-- e.g. vim.api.nvim_del_augroup_by_name("lazyvim_wrap_spell")

-- Poll for external file changes.
--
-- LazyVim already runs :checktime on FocusGained/TermClose/TermLeave, which
-- covers "come back to the window and see fresh content". It does not cover a
-- file being rewritten underneath you while you sit in the buffer (a build, a
-- formatter, git checkout, an agent editing files), since nothing re-checks
-- until focus changes.
--
-- CursorHold is not a fix: it fires once per idle period, not every
-- 'updatetime' ms, so an untouched buffer is never re-checked. A libuv timer
-- fires on wall-clock time regardless of input.
--
-- Cost is one stat() per loaded, named buffer -- ~23us for 20 buffers, i.e.
-- ~0.001% of a core at this interval. Buffers on network mounts (NFS/SSHFS)
-- are the exception: each stat is a round trip and the sweep can block the UI.
if _G.__checktime_timer then
  _G.__checktime_timer:stop()
  _G.__checktime_timer:close()
end
_G.__checktime_timer = vim.uv.new_timer()
_G.__checktime_timer:start(
  2000,
  2000,
  vim.schedule_wrap(function()
    -- Skip scratch/dashboard/picker buffers, and skip while the current buffer
    -- has unsaved edits so a reload prompt can't interrupt an active edit.
    if vim.o.buftype ~= "nofile" and not vim.bo.modified then
      pcall(vim.cmd, "checktime")
    end
  end)
)
